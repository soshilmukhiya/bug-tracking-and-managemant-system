export { default } from './dist/esm/dynamicIconImports.js';
