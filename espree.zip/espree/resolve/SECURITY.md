# Security

Please file a private vulnerability via GitHub, email [@ljharb](https://github.com/ljharb), or see https://tidelift.com/security if you have a potential security vulnerability to report.

## Incident Response

See our [Incident Response Process](.github/INCIDENT_RESPONSE_PROCESS.md).

## Threat Model

See [THREAT_MODEL.md](./THREAT_MODEL.md).
