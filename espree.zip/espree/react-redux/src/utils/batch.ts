// Default to a dummy "batch" implementation that just runs the callback
export function defaultNoopBatch(callback: () => void) {
  callback()
}
