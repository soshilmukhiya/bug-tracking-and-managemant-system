var set = require("./set.js");
var getPrototypeOf = require("./getPrototypeOf.js");
function _superPropSet(t, e, o, r, p, f) {
  return set(getPrototypeOf(f ? t.prototype : t), e, o, r, p);
}
module.exports = _superPropSet, module.exports.__esModule = true, module.exports["default"] = module.exports;