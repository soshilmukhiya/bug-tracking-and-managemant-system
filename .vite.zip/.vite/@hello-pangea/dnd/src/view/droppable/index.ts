export { default } from './connected-droppable';
