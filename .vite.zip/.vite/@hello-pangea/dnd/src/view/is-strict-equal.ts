export default (a: unknown, b: unknown): boolean => a === b;
