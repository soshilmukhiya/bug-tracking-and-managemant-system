// A scroll event will only be triggered when there is a value of at least 1px change
export default 1;
