import type { Config } from 'tailwindcss'

export default __CONFIG__ satisfies Config
