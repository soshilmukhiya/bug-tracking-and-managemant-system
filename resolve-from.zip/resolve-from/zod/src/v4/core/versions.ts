export const version = {
  major: 4,
  minor: 3,
  patch: 6 as number,
} as const;
